package com.te.base;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarInformationMaintainAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
