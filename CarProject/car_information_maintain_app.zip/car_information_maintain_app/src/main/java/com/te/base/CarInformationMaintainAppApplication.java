package com.te.base;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CarInformationMaintainAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CarInformationMaintainAppApplication.class, args);
	}

}
