package com.te.base.service;

import com.te.base.dto.CarDetails;

public interface CarService {

	public CarDetails getDetail(int id);
	
	public CarDetails addData(CarDetails details);
	
	public CarDetails updateData(CarDetails details);
	
	public void deleteData(int id);
	
	
	
	
}
