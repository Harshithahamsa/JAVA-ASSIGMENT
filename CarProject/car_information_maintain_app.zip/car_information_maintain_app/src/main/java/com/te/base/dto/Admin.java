package com.te.base.dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.hibernate.annotations.GeneratorType;

import lombok.Data;

@Entity

public class Admin {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int aId;
	private String aUsername;
	private String aPassword;
	
	
	public int getaId() {
		return aId;
	}


	public void setaId(int aId) {
		this.aId = aId;
	}


	public String getaUsername() {
		return aUsername;
	}


	public void setaUsername(String aUsername) {
		this.aUsername = aUsername;
	}


	public String getaPassword() {
		return aPassword;
	}


	public void setaPassword(String aPassword) {
		this.aPassword = aPassword;
	}


	


	
}
